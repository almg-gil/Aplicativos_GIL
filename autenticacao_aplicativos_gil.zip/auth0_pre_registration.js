// Configure the Action secret MATRICULAS_AUTORIZADAS as a comma-separated list.
exports.onExecutePreUserRegistration = async (event, api) => {
  const allowed = new Set((event.secrets.MATRICULAS_AUTORIZADAS || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean));
  const email = (event.user.email || '').trim().toLowerCase();
  const matricula = email.endsWith('@almg.gov.br') ? email.slice(0, -12) : '';
  const username = (event.user.username || '').trim().toLowerCase();
  if (!allowed.has(matricula) || !/^m\d{4,5}$/.test(matricula) || username !== matricula) {
    api.access.deny('signup_not_allowed', 'Cadastro não autorizado. Use sua matrícula e o e-mail institucional correspondente.');
  }
};
